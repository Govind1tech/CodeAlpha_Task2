import java.io.*;

public class FileManager {

    public static void saveBooking(String booking) {

        try (FileWriter fw = new FileWriter("bookings.txt", true)) {

            fw.write(booking + "\n");

        } catch(Exception e) {

            System.out.println(e);

        }
    }

    public static void viewBookings() {

        try (BufferedReader br = new BufferedReader(new FileReader("bookings.txt"))) {

            String line;

            while((line = br.readLine()) != null) {

                System.out.println(line);

            }

        } catch(Exception e) {

            System.out.println("No Bookings.");

        }
    }
}