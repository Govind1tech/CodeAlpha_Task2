import java.util.Scanner;

public class Payment {

    public static boolean makePayment(double amount) {

        try (Scanner sc = new Scanner(System.in)) {

            System.out.println("Total Amount : ₹" + amount);
            System.out.print("Enter Y to Pay : ");

            String ch = sc.next();

            if(ch.equalsIgnoreCase("Y")) {
                System.out.println("Payment Successful.");
                return true;
            }

            System.out.println("Payment Cancelled.");
            return false;
        }
    }
}