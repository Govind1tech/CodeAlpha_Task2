import java.io.Serializable;

public class Room implements Serializable {
    private final int roomNo;
    private final String category;
    private final double price;
    private boolean available;

    public Room(int roomNo, String category, double price, boolean available) {
        this.roomNo = roomNo;
        this.category = category;
        this.price = price;
        this.available = available;
    }

    public int getRoomNo() {
        return roomNo;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    @Override
    public String toString() {
        return roomNo + "," + category + "," + price + "," + available;
    }
}