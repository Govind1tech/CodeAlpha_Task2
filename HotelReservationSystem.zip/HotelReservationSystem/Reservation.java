public class Reservation {

    private final String customerName;
    private final int roomNo;
    private final String category;
    private final double amount;

    public Reservation(String customerName, int roomNo, String category, double amount) {
        this.customerName = customerName;
        this.roomNo = roomNo;
        this.category = category;
        this.amount = amount;
    }

    @Override
    public String toString() {
        return customerName + "," + roomNo + "," + category + "," + amount;
    }
}