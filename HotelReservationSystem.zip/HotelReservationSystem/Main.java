import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Hotel hotel = new Hotel();

        try (Scanner sc = new Scanner(System.in)) {

            while(true){

                System.out.println("\n===== HOTEL RESERVATION SYSTEM =====");

            System.out.println("1.Search Rooms");
            System.out.println("2.Book Room");
            System.out.println("3.Cancel Booking");
            System.out.println("4.View Bookings");
            System.out.println("5.Exit");

            System.out.print("Enter Choice : ");

            int ch = sc.nextInt();

            switch (ch) {
                case 1 -> hotel.searchRooms();
                case 2 -> hotel.bookRoom();
                case 3 -> hotel.cancelBooking();
                case 4 -> FileManager.viewBookings();
                case 5 -> System.exit(0);
                default -> System.out.println("Invalid Choice");
            }
        }
        }
    }
}