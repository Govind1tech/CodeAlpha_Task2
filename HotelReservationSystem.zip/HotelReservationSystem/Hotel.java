import java.util.*;

public class Hotel {

    ArrayList<Room> rooms = new ArrayList<>();
    private final Scanner sc = new Scanner(System.in);

    public Hotel() {

        rooms.add(new Room(101,"Standard",1500,true));
        rooms.add(new Room(102,"Standard",1500,true));
        rooms.add(new Room(201,"Deluxe",2500,true));
        rooms.add(new Room(202,"Deluxe",2500,true));
        rooms.add(new Room(301,"Suite",5000,true));
    }

    public void searchRooms() {

        for(Room r : rooms) {

            if(r.isAvailable()) {

                System.out.println(r.getRoomNo()+" "+r.getCategory()+" ₹"+r.getPrice());

            }

        }

    }

    public void bookRoom() {

        System.out.print("Enter Room Number : ");

        int room = sc.nextInt();

        sc.nextLine();

        for(Room r : rooms) {

            if(r.getRoomNo()==room && r.isAvailable()) {

                System.out.print("Customer Name : ");

                String name = sc.nextLine();

                if(Payment.makePayment(r.getPrice())) {

                    r.setAvailable(false);

                    Reservation res = new Reservation(name,r.getRoomNo(),r.getCategory(),r.getPrice());

                    FileManager.saveBooking(res.toString());

                    System.out.println("Booking Successful.");

                }

                return;

            }

        }

        System.out.println("Room Not Available.");

    }

    public void cancelBooking() {

        int room = sc.nextInt();

        for(Room r: rooms){

            if(r.getRoomNo()==room){

                r.setAvailable(true);

                System.out.println("Booking Cancelled.");

                return;

            }

        }

    }
}